/**
 * @description DJ Gondolf javascript du site OFFICIEL 
 * @author Edric Larouche
 * 
 */
